<?php
namespace TrxAddons\AiHelper;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class to make queries to the ThemeREX AI Assistant (TrxSuppilot).
 *
 * All requests go through the proxy upgrade.themerex.net which holds the OpenAI key and talks
 * to the OpenAI Responses API + Conversations API:
 *   chat()         - createResponse:    send the messages, get a conversation ID ('thread_id') and a response ID ('run_id')
 *   fetch_answer() - retrieveResponse:  poll the response state; execute the function calls requested by the model
 *                                       (via the filter 'trx_addons_filter_api_call') and send the results back
 *                                       with submitToolOutputs; when the response is completed - return the answer
 */
class TrxAiAssistants extends Api {

	/**
	 * Default polling interval (ms) if the proxy doesn't return its own value
	 */
	const FETCH_TIME = 2000;

	/**
	 * Class constructor.
	 *
	 * @access protected
	 */
	protected function __construct() {
		parent::__construct();
		$this->logger_section = 'trx-ai-assistants';
	}

	/**
	 * Return an object of the API
	 *
	 * @param string $token  API token for the API
	 *
	 * @return api  The object of the API
	 */
	public function get_api( $token = '' ) {
		if ( empty( $this->api ) ) {
			if ( empty( $token ) ) {
				$token = $this->get_token();
			}
			if ( ! empty( $token ) ) {
				$this->api = new \ThemeRex\Ai\TrxAiAssistants( $token );
			}
		}
		return $this->api;
	}

	/**
	 * Return an API token for the API from the plugin options
	 *
	 * @access protected
	 *
	 * @return string  API token for the API
	 */
	protected function get_token() {
		return '-not-need-';
	}

	/**
	 * Return a model name for the API
	 *
	 * @access static
	 *
	 *
	 * @return string  Model name for the API
	 */
	static function get_model() {
		return 'trx-ai-assistants/ai-assistant';
	}

	/**
	 * Return a maximum number of tokens in the prompt and response for specified model or from all available models
	 *
	 * @access static
	 *
	 * @param string $model  Model name (flow id) for the API. If '*' - return a maximum value from all available models
	 *
	 * @return int  The maximum number of tokens in the prompt and response for specified model or from all models
	 */
	static function get_max_tokens( $model = '' ) {
		$max_tokens = apply_filters( 'trx_addons_filter_ai_helper_trx_ai_assistants_max_tokens', 4000 );
		return (int)$max_tokens;
	}

	/**
	 * Send a single query (prompt) to the API
	 *
	 * @access public
	 *
	 * @param array $args    Query arguments: 'prompt', 'thread_id' (optional)
	 * @param array $params  Additional parameters (not used)
	 *
	 * @return array  Response from the API
	 */
	public function query( $args = array(), $params = array() ) {
		$args = array_merge( array(
			'prompt' => '',
		), $args );
		$args['messages'] = array();
		if ( ! empty( $args['prompt'] ) && ! is_bool( $args['prompt'] ) ) {
			$args['messages'][] = array(
									'role' => 'user',
									'content' => $args['prompt'],
								);
		}
		unset( $args['prompt'] );
		return $this->chat( $args, $params );
	}

	/**
	 * Send a chat messages to the API: create a new response in the conversation.
	 * The answer is not returned immediately - the response has a status 'queued' and must be fetched with fetch_answer()
	 *
	 * @access public
	 *
	 * @param array $args    Query arguments: 'messages' (array), 'thread_id' (string, conversation ID, optional)
	 * @param array $params  Additional parameters (not used)
	 *
	 * @return array  Response from the API: array( 'finish_reason' => 'queued', 'thread_id' => 'conv_...', 'run_id' => 'resp_...', 'fetch_time' => int )
	 */
	public function chat( $args = array(), $params = array() ) {
		$args = array_merge( array(
			'token' => $this->get_token(),
			'model' => $this->get_model(),
			'messages' => array(),
			'thread_id' => '',
		), $args );

		$response = false;

		if ( ! empty( $args['messages'] ) && is_array( $args['messages'] ) ) {

			$args = $this->prepare_args( $args );

			if ( count( $args['messages'] ) > 0 ) {

				$api = $this->get_api( $args['token'] );

				$result = $api->createResponse( array(
					'conversationId' => ! empty( $args['thread_id'] ) ? $args['thread_id'] : '',
					'messages'       => $args['messages'],
					'tools'          => $this->get_tools(),
					'metadata'       => $this->get_metadata(),
				) );

				$response = $this->prepare_queued_response( $result, $args['thread_id'], __( "Can't create a response", 'trx_addons' ) );

			} else {
				$response = array(
					'finish_reason' => 'error',
					'error' => __( 'Error! The prompt is empty.', 'trx_addons' ),
				);
			}
		}
		return $response;
	}

	/**
	 * Check the response status and return the answer if the response is completed.
	 * If the model requests the function calls - execute them and submit the results back (a new response is created).
	 *
	 * @access public
	 *
	 * @param string $thread_id  Conversation ID
	 * @param string $run_id     Response ID
	 *
	 * @return array  Response from the API
	 */
	public function fetch_answer( $thread_id, $run_id ) {
		$response = array(
			'finish_reason' => 'queued',
			'thread_id' => $thread_id,
			'run_id' => $run_id,
			'text' => '',
		);
		if ( ! empty( $run_id ) ) {

			$api = $this->get_api( $this->get_token() );

			$result = $api->retrieveResponse( $run_id );

			if ( ! empty( $result['status'] ) ) {

				if ( ! empty( $result['conversation_id'] ) ) {
					$thread_id = $response['thread_id'] = $result['conversation_id'];
				}

				// The response is still in progress - keep polling
				if ( in_array( $result['status'], array( 'queued', 'in_progress' ) ) ) {
					$response['fetch_time'] = self::FETCH_TIME;

				// The response is completed (or cut off by the max_output_tokens limit - 'incomplete')
				} else if ( in_array( $result['status'], array( 'completed', 'incomplete' ) ) ) {

					$calls = $this->get_function_calls( $result );

					// The model requests the function calls - execute them and submit the results
					if ( $result['status'] == 'completed' && count( $calls ) > 0 ) {
						$outputs = array();
						foreach ( $calls as $call ) {
							$rez = apply_filters(
										'trx_addons_filter_api_call',
										'',
										$call['name'],
										! empty( $call['arguments'] ) ? json_decode( $call['arguments'], true ) : array()
							);
							if ( empty( $rez ) ) {
								$rez = array(
										'status' => 'error',
										'message' => __( 'Unsupported function called', 'trx_addons' )
								);
							}
							$outputs[] = array(
											'call_id' => $call['call_id'],
											'output'  => json_encode( $rez )
							);
						}
						$submit = $api->submitToolOutputs( array(
							'conversationId' => $thread_id,
							'outputs'        => $outputs,
							'tools'          => $this->get_tools(),
							'metadata'       => $this->get_metadata(),
						) );
						$response = $this->prepare_queued_response( $submit, $thread_id, __( "Can't submit the results of the function calls", 'trx_addons' ) );

					// The answer is ready
					} else {
						$args = array(
							'model' => static::get_model(),
							'thread_id' => $thread_id,
							'run_id' => $run_id,
						);
						$response = $this->prepare_response( $result, $args );
						if ( ! empty( $response['choices'][0]['message']['content'] ) ) {
							$this->logger->log( $response, 'chat', $args, $this->logger_section );
						} else {
							$response = array(
								'finish_reason' => 'error',
								'thread_id' => $thread_id,
								'run_id' => $run_id,
								'error' => $result['status'] == 'incomplete'
											? __( 'The answer is incomplete. Please, try to ask a shorter question.', 'trx_addons' )
											: __( 'The assistant returned an empty answer. Please, try again.', 'trx_addons' ),
							);
						}
					}

				// The response is failed or cancelled
				} else {
					$response['finish_reason'] = 'error';
					$response['error'] = ! empty( $result['error']['message'] )
											? $result['error']['message']
											: sprintf( __( 'The response %s. Please, try again.', 'trx_addons' ), $result['status'] );
				}

			} else if ( ! empty( $result['error'] ) ) {
				$response['finish_reason'] = 'error';
				$response['error'] = ! empty( $result['error']['message'] )
										? $result['error']['message']
										: ( is_string( $result['error'] ) ? $result['error'] : __( 'Unexpected response from the server.', 'trx_addons' ) );
			} else {
				$response['finish_reason'] = 'error';
				$response['error'] = __( 'Unexpected response from the server - no status field.', 'trx_addons' );
			}
		} else {
			$response['finish_reason'] = 'error';
			$response['error'] = __( 'Response ID is not specified.', 'trx_addons' );
		}
		return $response;
	}

	/**
	 * Convert the result of createResponse / submitToolOutputs to the 'queued' response for the chat
	 *
	 * @access private
	 *
	 * @param array  $result     Result from the proxy: 'id', 'status', 'conversation_id', 'fetch_time' or 'error'
	 * @param string $thread_id  Conversation ID passed to the request (used if the proxy doesn't return it)
	 * @param string $error      Default error message
	 *
	 * @return array  Response for the chat
	 */
	private function prepare_queued_response( $result, $thread_id, $error ) {
		if ( ! empty( $result['id'] ) ) {
			$response = array(
				'finish_reason' => 'queued',
				'run_id' => $result['id'],
				'thread_id' => ! empty( $result['conversation_id'] ) ? $result['conversation_id'] : $thread_id,
				'fetch_time' => ! empty( $result['fetch_time'] ) ? max( 500, (int)$result['fetch_time'] ) : self::FETCH_TIME,
			);
		} else {
			$response = array(
				'finish_reason' => 'error',
				'thread_id' => $thread_id,
				'error' => ! empty( $result['error']['message'] )
							? $result['error']['message']
							: ( ! empty( $result['error'] ) && is_string( $result['error'] ) ? $result['error'] : $error ),
			);
		}
		return $response;
	}

	/**
	 * Return the list of the function calls requested by the model
	 *
	 * @access private
	 *
	 * @param array $result  Result of retrieveResponse
	 *
	 * @return array  List of the calls: array( 'call_id', 'name', 'arguments' )
	 */
	private function get_function_calls( $result ) {
		$calls = array();
		if ( ! empty( $result['output'] ) && is_array( $result['output'] ) ) {
			foreach ( $result['output'] as $item ) {
				if ( ! empty( $item['type'] ) && $item['type'] == 'function_call' && ! empty( $item['name'] ) && ! empty( $item['call_id'] ) ) {
					$calls[] = array(
						'call_id' => $item['call_id'],
						'name' => $item['name'],
						'arguments' => ! empty( $item['arguments'] ) ? $item['arguments'] : '',
					);
				}
			}
		}
		return $calls;
	}

	/**
	 * Return the list of the tools (function schemas) for the assistant
	 *
	 * @access protected
	 *
	 * @return array  List of the tools in the Responses API format
	 */
	protected function get_tools() {
		$tools = class_exists( 'TrxAddons\AiHelper\AssistantTools\Helper' )
					? AssistantTools\Helper::get_tools()
					: array();
		return apply_filters( 'trx_addons_filter_ai_helper_trx_ai_assistant_tools', $tools );
	}

	/**
	 * Return the metadata to attach to the conversation and responses (visible in the OpenAI dashboard and the proxy journal)
	 *
	 * @access protected
	 *
	 * @return array  Metadata: key => value (string)
	 */
	protected function get_metadata() {
		$theme_info = function_exists( 'trx_addons_get_theme_info' ) ? trx_addons_get_theme_info( false ) : array();
		return apply_filters( 'trx_addons_filter_ai_helper_trx_ai_assistant_metadata', array(
			'plugin_version' => TRX_ADDONS_VERSION,
			'theme_version'  => ! empty( $theme_info['theme_version'] ) ? $theme_info['theme_version'] : '',
			'wp_version'     => get_bloginfo( 'version' ),
		) );
	}

	/**
	 * Convert a response object to the format, compatible with OpenAI API response
	 *
	 * @access protected
	 *
	 * @param array $response  Result of retrieveResponse: 'id', 'status', 'output', 'usage'
	 * @param array $args      Query arguments: 'model', 'thread_id', 'run_id'
	 *
	 * @return array  Response in the OpenAI API format: 'finish_reason', 'model', 'thread_id', 'run_id', 'response_id', 'usage', 'choices'
	 */
	protected function prepare_response( $response, $args ) {
		$content = ! empty( $response['output'] ) ? Utils::parse_responses_output( $response['output'] ) : '';
		if ( ! empty( $content ) && ! empty( $response['status'] ) && $response['status'] == 'incomplete' ) {
			$content .= '<br><em>' . esc_html__( '(The answer was cut off due to its length)', 'trx_addons' ) . '</em>';
		}
		$prompt_tokens     = ! empty( $response['usage']['input_tokens'] )  ? (int)$response['usage']['input_tokens']  : 0;
		$completion_tokens = ! empty( $response['usage']['output_tokens'] ) ? (int)$response['usage']['output_tokens'] : ( ! empty( $content ) ? $this->count_tokens( $content ) : 0 );
		$total_tokens      = ! empty( $response['usage']['total_tokens'] )  ? (int)$response['usage']['total_tokens']  : $prompt_tokens + $completion_tokens;
		return array(
			'finish_reason' => 'stop',
			'model' => ! empty( $args['model'] ) ? $args['model'] : static::get_model(),
			'run_id' => ! empty( $args['run_id'] ) ? $args['run_id'] : '',
			'thread_id' => ! empty( $args['thread_id'] ) ? $args['thread_id'] : '',
			'response_id' => ! empty( $response['id'] ) ? $response['id'] : '',
			'usage' => array(
						'prompt_tokens' => $prompt_tokens,
						'completion_tokens' => $completion_tokens,
						'total_tokens' => $total_tokens,
						),
			'choices' => array(
							array(
								'message' => array(
									'role' => 'assistant',
									'content' => $content
								)
							)
						)
		);
	}

	/**
	 * Prepare args for the API: clean the messages and convert the attachments to the Responses API input format
	 *
	 * @access protected
	 *
	 * @param array $args  Query arguments
	 *
	 * @return array  Prepared query arguments
	 */
	protected function prepare_args( $args = array() ) {
		if ( ! empty( $args['messages'] ) && is_array( $args['messages'] ) ) {
			$messages = array();
			foreach ( $args['messages'] as $message ) {
				if ( empty( $message['role'] ) || ! in_array( $message['role'], array( 'user', 'assistant' ) ) || empty( $message['content'] ) || ! is_string( $message['content'] ) ) {
					continue;
				}
				$content = $message['content'];
				// Remove all Gutenberg block comments
				$content = preg_replace( '/<!--[^>]*-->/', '', $content );
				// The assistant messages in the chat history are stored as HTML - convert them back to the plain text
				if ( $message['role'] == 'assistant' ) {
					$content = preg_replace( '/<br\s*\/?>|<\/(p|li|h[1-6]|div|tr)>/i', "\n", $content );
					$content = html_entity_decode( wp_strip_all_tags( $content ), ENT_QUOTES | ENT_HTML5, 'UTF-8' );
				}
				// Remove duplicate newlines
				$content = trim( preg_replace( '/[\r\n]{2,}/', "\n", $content ) );
				if ( $content === '' ) {
					continue;
				}
				$item = array(
					'role' => $message['role'],
					'content' => $content,
				);
				// Add attachments (images) to the message content
				if ( $message['role'] == 'user' && ! empty( $message['attachments'] ) && is_array( $message['attachments'] ) ) {
					$item = $this->add_attachments_to_message_content( $item, $message['attachments'] );
				}
				$messages[] = $item;
			}
			$args['messages'] = $messages;
			unset( $args['max_tokens'] );
		}
		if ( ! empty( $args['model'] ) ) {
			$args['model'] = str_replace( 'trx-ai-assistants/', '', $args['model'] );
		}
		return $args;
	}

	/**
	 * Set a message content for the API as an array of the input parts if the attachments (images) are present
	 *
	 * @access private
	 *
	 * @param array $message      The message: 'role', 'content' (string)
	 * @param array $attachments  The attachments: array( array( 'name' => 'file name', 'file' => 'path to the uploaded file' ) )
	 *
	 * @return array  Prepared message
	 */
	private function add_attachments_to_message_content( $message, $attachments ) {
		$parts = array();
		$image_ext = Utils::get_allowed_attachments( 'image' );
		foreach ( $attachments as $attachment ) {
			if ( empty( $attachment['name'] ) || empty( $attachment['file'] ) || ! file_exists( $attachment['file'] ) ) {
				continue;
			}
			$ext = strtolower( pathinfo( $attachment['name'], PATHINFO_EXTENSION ) );
			if ( in_array( $ext, $image_ext ) ) {
				$parts[] = array(
					'type' => 'input_image',
					'image_url' => 'data:image/' . ( $ext == 'jpg' ? 'jpeg' : $ext ) . ';base64,' . base64_encode( trx_addons_fgc( $attachment['file'] ) ),
				);
			}
		}
		if ( count( $parts ) > 0 ) {
			$message['content'] = array_merge(
				array(
					array(
						'type' => 'input_text',
						'text' => $message['content'],
					)
				),
				$parts
			);
		}
		return $message;
	}


	/**
	 * Extend the support period
	 *
	 * @access public
	 *
	 * @param array $support_key  A purchase key for the support
	 *
	 * @return array  Response from the API
	 */
	public function add_support_key( $support_key ) {
		if ( ! empty( $support_key ) ) {
			$api = $this->get_api( $this->get_token() );
			$response = $api->addSupportKey( $support_key );
			$this->logger->log( $response, 'add-support', array( 'key' => $support_key ), $this->logger_section . '-support' );
		} else {
			$response = array(
				'status' => 'error',
				'error' => array(
					'message' => __( 'Support key is empty', 'trx_addons' )
				)
			);
		}
		return $response;
	}


	/**
	 * Parse the image and return a layout
	 *
	 * @access public
	 *
	 * @param array $args  An array with the image content or URL, method of sending and extension
	 *
	 * @return string  Parsed layout from the image
	 */
	public function image_to_layout( $args ) {
		if ( ! empty( $args['image'] ) ) {
			$api = $this->get_api( $this->get_token() );
			$response = $api->imageToLayout( $args );
			$this->logger->log( $response, 'image-to-layout', array(), $this->logger_section . '-itl' );
		} else {
			$response = array(
				'status' => 'error',
				'error' => array(
					'message' => __( 'No image to be parsed!', 'trx_addons' )
				)
			);
		}
		return $response;
	}


	/**
	 * Transcript the audio and return a text
	 *
	 * @access public
	 *
	 * @param array $args  An array with the audio content or URL, method of sending and extension
	 *
	 * @return string  Transcripted text from the audio
	 */
	public function transcription( $args ) {
		if ( ! empty( $args['init_audio'] ) ) {
			$api = $this->get_api( $this->get_token() );
			$response = $api->speechToText( $args );
			$this->logger->log( $response, 'speech-to-text', array(), $this->logger_section . '-stt' );
		} else {
			$response = array(
				'status' => 'error',
				'error' => array(
					'message' => __( 'No audio to be transcripted!', 'trx_addons' )
				)
			);
		}
		return $response;
	}

}
