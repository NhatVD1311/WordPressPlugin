<?php
namespace TrxAddons\AiHelper;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class to make queries to the custom OpenAI assistants (models 'openai-assistants/{id}').
 *
 * Since the plugin 2.46.0 the assistants are configured in the plugin options (option 'ai_helper_models_openai_assistants':
 * 'id', 'title', 'model', 'instructions', 'vector_store_ids') and work on top of the OpenAI Responses API + Conversations API
 * (the Assistants API was shut down by OpenAI on 2026-08-26):
 *   chat()         - create a conversation (if the passed 'thread_id' is empty or invalid) and start a background response:
 *                    returns a conversation ID ('thread_id') and a response ID ('run_id') with the status 'queued'
 *   query()        - the same for a single prompt without a conversation (the function calls are continued via 'previous_response_id')
 *   fetch_answer() - poll the response state; execute the function calls requested by the model (via the filter
 *                    'trx_addons_filter_api_call') and send the results back (a new response is created);
 *                    when the response is completed - return the answer
 *
 * The function tools for the assistants are registered via the filter 'trx_addons_filter_ai_helper_openai_assistants_tools'.
 */
class OpenAiAssistants extends Api {

	/**
	 * Polling interval (ms) for the chat to fetch the answer
	 */
	const FETCH_TIME = 2000;

	/**
	 * Regexp for the OpenAI object IDs by prefix
	 */
	private static $id_patterns = array(
		'conv' => '/^conv_[A-Za-z0-9]+$/',
		'resp' => '/^resp_[A-Za-z0-9]+$/',
		'call' => '/^call_[A-Za-z0-9]+$/',
		'vs'   => '/^vs_[A-Za-z0-9]+$/',
	);

	/**
	 * Class constructor.
	 *
	 * @access protected
	 */
	protected function __construct() {
		parent::__construct();
		$this->logger_section = 'open-ai-assistants';
		$this->token_option = 'ai_helper_token_openai';
	}

	/**
	 * Return an object of the API
	 *
	 * @param string $token  API token for the API
	 *
	 * @return api  The object of the API
	 */
	public function get_api( $token = '' ) {
		if ( empty( $this->api ) ) {
			if ( empty( $token ) ) {
				$token = $this->get_token();
			}
			if ( ! empty( $token ) ) {
				$this->api = new \ThemeRex\OpenAi\OpenAi( $token );
				$proxy = trx_addons_get_option( 'ai_helper_proxy_openai', '' );
				$proxy_auth = trx_addons_get_option( 'ai_helper_proxy_auth_openai', '' );
				if ( ! empty( $proxy ) ) {
					$this->api->setProxy( $proxy, $proxy_auth );
				}
			}
		}
		return $this->api;
	}

	/**
	 * Return a model name for the API
	 *
	 * @access static
	 *
	 *
	 * @return string  Model name for the API
	 */
	static function get_model() {
		$default_model = trx_addons_get_option( 'ai_helper_text_model_default', '' );
		return Utils::is_openai_assistants_model( $default_model ) ? $default_model : '';
	}

	/**
	 * Return a maximum number of tokens in the prompt and response for specified model or from all available models
	 *
	 * @access static
	 *
	 * @param string $model  Model name (flow id) for the API. If '*' - return a maximum value from all available models
	 *
	 * @return int  The maximum number of tokens in the prompt and response for specified model or from all models
	 */
	static function get_max_tokens( $model = '' ) {
		$max_tokens = apply_filters( 'trx_addons_filter_ai_helper_openai_assistants_max_tokens', 4000 );
		return (int)$max_tokens;
	}

	/**
	 * Return the assistant settings from the plugin options by its ID
	 *
	 * @access static
	 *
	 * @param string $id  Assistant ID (with or without the prefix 'openai-assistants/')
	 *
	 * @return array  Assistant settings: 'id', 'title', 'model' (without the prefix 'openai/'), 'instructions', 'vector_store_ids' (array)
	 *                or an empty array if the assistant is not found in the plugin options
	 */
	static function get_assistant( $id ) {
		$id = self::get_assistant_id( $id );
		$assistants = Lists::get_openai_assistants();
		if ( empty( $id ) || empty( $assistants[ $id ] ) || ! is_array( $assistants[ $id ] ) ) {
			return array();
		}
		$assistant = $assistants[ $id ];
		$model = ! empty( $assistant['model'] ) && is_string( $assistant['model'] ) ? trim( str_replace( 'openai/', '', $assistant['model'] ) ) : '';
		if ( empty( $model ) ) {
			$model = str_replace( 'openai/', '', OpenAi::get_default_model() );
		}
		$vector_store_ids = array();
		if ( ! empty( $assistant['vector_store_ids'] ) && is_string( $assistant['vector_store_ids'] ) ) {
			foreach ( preg_split( '/[\s,;]+/', $assistant['vector_store_ids'] ) as $vs ) {
				$vs = trim( $vs );
				if ( self::is_valid_id( $vs, 'vs' ) && ! in_array( $vs, $vector_store_ids ) ) {
					$vector_store_ids[] = $vs;
				}
			}
		}
		return apply_filters( 'trx_addons_filter_ai_helper_openai_assistant', array(
			'id'               => $id,
			'title'            => ! empty( $assistant['title'] ) && is_string( $assistant['title'] ) ? trim( $assistant['title'] ) : $id,
			'model'            => $model,
			'instructions'     => ! empty( $assistant['instructions'] ) && is_string( $assistant['instructions'] ) ? trim( $assistant['instructions'] ) : '',
			'vector_store_ids' => $vector_store_ids,
		), $id );
	}

	/**
	 * Return the assistant ID without the prefix 'openai-assistants/'
	 *
	 * @access static
	 *
	 * @param string $model  Model name (assistant ID with or without the prefix)
	 *
	 * @return string  Assistant ID
	 */
	static function get_assistant_id( $model ) {
		return is_string( $model ) ? trim( str_replace( 'openai-assistants/', '', $model ) ) : '';
	}

	/**
	 * Check if the string is a valid OpenAI object ID with the specified prefix
	 *
	 * @access static
	 *
	 * @param string $id    ID to check
	 * @param string $type  Type of the ID: 'conv' | 'resp' | 'call' | 'vs'
	 *
	 * @return bool
	 */
	static function is_valid_id( $id, $type ) {
		return ! empty( $id ) && is_string( $id ) && ! empty( self::$id_patterns[ $type ] ) && preg_match( self::$id_patterns[ $type ], $id );
	}

	/**
	 * Send a single query (prompt) to the API without a conversation.
	 * The answer is not returned immediately - the response has a status 'queued' and must be fetched with fetch_answer()
	 *
	 * @access public
	 *
	 * @param array $args    Query arguments: 'model', 'prompt', 'system_prompt', 'max_tokens', 'temperature', 'response_format'
	 * @param array $params  Additional parameters (not used)
	 *
	 * @return array  Response from the API: array( 'finish_reason' => 'queued', 'thread_id' => '', 'run_id' => 'resp_...', 'fetch_time' => int )
	 */
	public function query( $args = array(), $params = array() ) {
		$args = array_merge( array(
			'token' => $this->get_token(),
			'model' => $this->get_model(),
			'prompt' => '',
			'system_prompt' => '',
		), $args );

		$args['messages'] = array();
		if ( ! empty( $args['prompt'] ) && ! is_bool( $args['prompt'] ) ) {
			$args['messages'][] = array(
									'role' => 'user',
									'content' => $args['prompt'],
								);
		}
		unset( $args['prompt'] );

		$response = false;

		if ( ! empty( $args['token'] ) && ! empty( $args['model'] ) ) {

			$args = $this->prepare_args( $args );

			$assistant = self::get_assistant( $args['model'] );

			if ( empty( $assistant ) ) {
				$response = $this->prepare_error_response( $this->get_assistant_not_found_message( $args['model'] ) );

			} else {
				// A single query has no conversation - the system prompt is always sent as a 'developer' message
				$input = $this->build_input( $args['messages'], $args['system_prompt'] );

				if ( count( $input ) == 0 ) {
					$response = $this->prepare_error_response( __( 'Error! The prompt is empty.', 'trx_addons' ) );

				} else {
					$api = $this->get_api( $args['token'] );

					$result = $api->responses( $this->build_request( $assistant, $input, $args ) );

					$response = $this->prepare_queued_response( $result, '', __( "Can't create a response", 'trx_addons' ) );
				}
			}
		}

		return $response;
	}

	/**
	 * Send a chat messages to the API: create a conversation (if needed) and a new response in it.
	 * The answer is not returned immediately - the response has a status 'queued' and must be fetched with fetch_answer()
	 *
	 * @access public
	 *
	 * @param array $args    Query arguments: 'model', 'messages', 'system_prompt', 'thread_id' (conversation ID, optional),
	 *                       'max_tokens', 'temperature'. The 'response_id' is ignored - the context is stored in the conversation
	 * @param array $params  Additional parameters (not used)
	 *
	 * @return array  Response from the API: array( 'finish_reason' => 'queued', 'thread_id' => 'conv_...', 'run_id' => 'resp_...', 'fetch_time' => int )
	 */
	public function chat( $args = array(), $params = array() ) {
		$args = array_merge( array(
			'token' => $this->get_token(),
			'model' => $this->get_model(),
			'messages' => array(),
			'system_prompt' => '',
			'thread_id' => '',
		), $args );

		$response = false;

		if ( ! empty( $args['token'] ) && ! empty( $args['model'] ) && ! empty( $args['messages'] ) && is_array( $args['messages'] ) ) {

			$args = $this->prepare_args( $args );

			$assistant = self::get_assistant( $args['model'] );

			if ( empty( $assistant ) ) {
				$response = $this->prepare_error_response( $this->get_assistant_not_found_message( $args['model'] ) );

			} else if ( count( $args['messages'] ) == 0 ) {
				$response = $this->prepare_error_response( __( 'Error! The prompt is empty.', 'trx_addons' ) );

			} else {
				$api = $this->get_api( $args['token'] );

				$error = '';
				$conversation_id = self::is_valid_id( $args['thread_id'], 'conv' ) ? $args['thread_id'] : '';
				$is_new = empty( $conversation_id );

				if ( $is_new ) {
					$conversation_id = $this->create_conversation( $assistant, $error );
				}

				if ( empty( $conversation_id ) ) {
					$response = $this->prepare_error_response( $error );

				} else {
					// For an existing conversation send only the last message (the history is stored on the OpenAI side),
					// for a new conversation send the whole history and the system prompt
					$input = $is_new
								? $this->build_input( $args['messages'], $args['system_prompt'] )
								: $this->build_input( array( $args['messages'][ count( $args['messages'] ) - 1 ] ) );

					$result = $api->responses( $this->build_request( $assistant, $input, $args, array( 'conversation' => $conversation_id ) ) );

					// If the passed conversation is not found (expired, deleted, belongs to another project) -
					// retry once with a new conversation and the full history
					if ( ! $is_new && $this->is_conversation_error( $result ) ) {
						$conversation_id = $this->create_conversation( $assistant, $error );
						if ( ! empty( $conversation_id ) ) {
							$input = $this->build_input( $args['messages'], $args['system_prompt'] );
							$result = $api->responses( $this->build_request( $assistant, $input, $args, array( 'conversation' => $conversation_id ) ) );
						}
					}

					$response = $this->prepare_queued_response( $result, $conversation_id, __( "Can't create a response", 'trx_addons' ) );
				}
			}
		}

		return $response;
	}

	/**
	 * Check the response status and return the answer if the response is completed.
	 * If the model requests the function calls - execute them and submit the results back (a new response is created).
	 *
	 * @access public
	 *
	 * @param string $thread_id  Conversation ID (empty for the single queries)
	 * @param string $run_id     Response ID
	 *
	 * @return array  Response from the API
	 */
	public function fetch_answer( $thread_id, $run_id ) {
		$response = array(
			'finish_reason' => 'queued',
			'thread_id' => $thread_id,
			'run_id' => $run_id,
			'text' => '',
		);
		if ( ! empty( $run_id ) ) {

			$api = $this->get_api( $this->get_token() );

			$result = ! empty( $api ) ? $api->getResponse( $run_id ) : false;

			if ( is_array( $result ) && ! empty( $result['status'] ) ) {

				if ( ! empty( $result['conversation']['id'] ) ) {
					$thread_id = $response['thread_id'] = $result['conversation']['id'];
				}

				// The response is still in progress - keep polling
				if ( in_array( $result['status'], array( 'queued', 'in_progress' ) ) ) {
					$response['fetch_time'] = self::FETCH_TIME;

				// The response is completed (or cut off by the max_output_tokens limit - 'incomplete')
				} else if ( in_array( $result['status'], array( 'completed', 'incomplete' ) ) ) {

					// Restore the assistant settings and the request parameters from the metadata of the response
					$metadata = ! empty( $result['metadata'] ) && is_array( $result['metadata'] ) ? $result['metadata'] : array();
					$assistant_id = ! empty( $metadata['assistant_id'] ) ? $metadata['assistant_id'] : '';
					$assistant = self::get_assistant( $assistant_id );
					$model = ! empty( $assistant_id )
								? 'openai-assistants/' . $assistant_id
								: ( ! empty( $result['model'] ) ? $result['model'] : __( 'OpenAI Assistant', 'trx_addons' ) );

					$calls = $this->get_function_calls( $result );

					// The model requests the function calls - execute them and submit the results
					if ( $result['status'] == 'completed' && count( $calls ) > 0 ) {
						$outputs = array();
						foreach ( $calls as $call ) {
							$rez = apply_filters(
										'trx_addons_filter_api_call',
										'',
										$call['name'],
										! empty( $call['arguments'] ) ? json_decode( $call['arguments'], true ) : array()
							);
							if ( empty( $rez ) ) {
								$rez = array(
										'status' => 'error',
										'message' => __( 'Unsupported function called', 'trx_addons' )
								);
							}
							$outputs[] = array(
								'type'    => 'function_call_output',
								'call_id' => $call['call_id'],
								'output'  => is_string( $rez ) ? $rez : json_encode( $rez ),
							);
						}
						if ( empty( $assistant ) ) {
							// The assistant was removed from the plugin options while the response was in progress
							$assistant = array(
								'id' => $assistant_id,
								'model' => ! empty( $result['model'] ) ? $result['model'] : str_replace( 'openai/', '', OpenAi::get_default_model() ),
								'instructions' => ! empty( $result['instructions'] ) && is_string( $result['instructions'] ) ? $result['instructions'] : '',
								'vector_store_ids' => array(),
							);
						}
						// Continue the conversation (chat) or the response chain (single query)
						$context = self::is_valid_id( $thread_id, 'conv' )
									? array( 'conversation' => $thread_id )
									: array( 'previous_response_id' => $run_id );
						$submit = $api->responses( $this->build_request( $assistant, $outputs, $this->get_args_from_metadata( $metadata ), $context ) );
						$response = $this->prepare_queued_response( $submit, $thread_id, __( "Can't submit the results of the function calls", 'trx_addons' ) );

					// The answer is ready
					} else {
						$args = array(
							'model' => $model,
							'thread_id' => $thread_id,
							'run_id' => $run_id,
						);
						$response = $this->prepare_response( $result, $args );
						if ( ! empty( $response['choices'][0]['message']['content'] ) ) {
							$this->logger->log( $response, 'chat', $args, $this->logger_section );
						} else {
							$response = $this->prepare_error_response(
								$result['status'] == 'incomplete'
									? __( 'The answer is incomplete. Please, try to ask a shorter question.', 'trx_addons' )
									: __( 'The assistant returned an empty answer. Please, try again.', 'trx_addons' ),
								$thread_id,
								$run_id
							);
						}
					}

				// The response is failed or cancelled
				} else {
					$response['finish_reason'] = 'error';
					$response['error'] = ! empty( $result['error']['message'] )
											? $result['error']['message']
											: sprintf( __( 'The response %s. Please, try again.', 'trx_addons' ), $result['status'] );
				}

			} else {
				$response['finish_reason'] = 'error';
				$response['error'] = $this->get_error_message( $result, __( 'Unexpected response from the server - no status field.', 'trx_addons' ) );
			}
		} else {
			$response['finish_reason'] = 'error';
			$response['error'] = __( 'Response ID is not specified.', 'trx_addons' );
		}
		return $response;
	}

	/**
	 * Create a new conversation on the OpenAI side
	 *
	 * @access protected
	 *
	 * @param array  $assistant  Assistant settings
	 * @param string $error      Returns an error message if the conversation is not created
	 *
	 * @return string  Conversation ID or empty string
	 */
	protected function create_conversation( $assistant, &$error ) {
		$api = $this->get_api( $this->get_token() );
		$result = $api->conversations( array(
			'metadata' => $this->get_metadata( $assistant ),
		) );
		if ( is_array( $result ) && ! empty( $result['id'] ) && self::is_valid_id( $result['id'], 'conv' ) ) {
			return $result['id'];
		}
		$error = $this->get_error_message( $result, __( "Can't create a conversation", 'trx_addons' ) );
		return '';
	}

	/**
	 * Build the request body for the endpoint 'POST /v1/responses'
	 *
	 * @access protected
	 *
	 * @param array $assistant  Assistant settings: 'id', 'model', 'instructions', 'vector_store_ids'
	 * @param array $input      Input items: messages or function_call_output items
	 * @param array $args       Query arguments: 'max_tokens', 'temperature', 'response_format'
	 * @param array $context    array( 'conversation' => 'conv_...' ) or array( 'previous_response_id' => 'resp_...' ) or empty
	 *
	 * @return array  Request body
	 */
	protected function build_request( $assistant, $input, $args = array(), $context = array() ) {
		$request = array(
			'model'      => $assistant['model'],
			'input'      => $input,
			'background' => true,
			'store'      => true,
			'truncation' => 'auto',
			'metadata'   => $this->get_metadata( $assistant, $args ),
		);
		if ( ! empty( $assistant['instructions'] ) ) {
			$request['instructions'] = self::replace_placeholders( $assistant['instructions'] );
		}
		if ( ! empty( $context['conversation'] ) ) {
			$request['conversation'] = $context['conversation'];
		} else if ( ! empty( $context['previous_response_id'] ) ) {
			$request['previous_response_id'] = $context['previous_response_id'];
		}
		$tools = $this->build_tools( $assistant );
		if ( count( $tools ) > 0 ) {
			$request['tools'] = $tools;
		}
		if ( ! empty( $args['max_tokens'] ) && (int)$args['max_tokens'] > 0 ) {
			$request['max_output_tokens'] = (int)$args['max_tokens'];
		}
		if ( isset( $args['temperature'] ) && $args['temperature'] !== '' && $args['temperature'] !== null ) {
			$request['temperature'] = (float)$args['temperature'];
		}
		// Convert 'response_format' (Chat Completions format) to 'text.format' (Responses format)
		if ( ! empty( $args['response_format']['type'] ) ) {
			$format = $args['response_format'];
			if ( $format['type'] == 'json_schema' && ! empty( $format['json_schema'] ) ) {
				$format['schema'] = ! empty( $format['json_schema']['schema'] ) ? $format['json_schema']['schema'] : array();
				$format['name'] = ! empty( $format['json_schema']['name'] ) ? $format['json_schema']['name'] : 'text_generator';
				$format['strict'] = isset( $format['json_schema']['strict'] ) ? (bool)$format['json_schema']['strict'] : true;
				unset( $format['json_schema'] );
			}
			$request['text'] = array( 'format' => $format );
		}
		return apply_filters( 'trx_addons_filter_ai_helper_openai_assistants_request', $request, $assistant, $args, $context );
	}

	/**
	 * Replace the placeholders in the instructions of the assistant with the site data:
	 * {domain}, {site_name}, {site_url}, {theme_name}, {theme_slug}, {theme_version}, {plugin_version}
	 * (the same placeholders as in the instructions of the ThemeREX AI Assistant on the proxy)
	 *
	 * @access static
	 *
	 * @param string $text  Instructions with placeholders
	 *
	 * @return string  Instructions with the replaced placeholders
	 */
	static function replace_placeholders( $text ) {
		if ( ! is_string( $text ) || strpos( $text, '{' ) === false ) {
			return $text;
		}
		$theme_info = function_exists( 'trx_addons_get_theme_info' ) ? trx_addons_get_theme_info( false ) : array();
		$placeholders = apply_filters( 'trx_addons_filter_ai_helper_openai_assistants_placeholders', array(
			'{domain}'         => function_exists( 'trx_addons_get_site_domain' ) ? trx_addons_get_site_domain() : (string)wp_parse_url( home_url(), PHP_URL_HOST ),
			'{site_name}'      => get_bloginfo( 'name' ),
			'{site_url}'       => home_url(),
			'{theme_name}'     => ! empty( $theme_info['theme_name'] ) ? $theme_info['theme_name'] : wp_get_theme( get_template() )->get( 'Name' ),
			'{theme_slug}'     => ! empty( $theme_info['theme_slug'] ) ? $theme_info['theme_slug'] : get_template(),
			'{theme_version}'  => ! empty( $theme_info['theme_version'] ) ? $theme_info['theme_version'] : '',
			'{plugin_version}' => TRX_ADDONS_VERSION,
		) );
		return str_replace( array_keys( $placeholders ), array_map( 'strval', array_values( $placeholders ) ), $text );
	}

	/**
	 * Build the tools list: file_search over the vector stores of the assistant + function tools from the filter
	 *
	 * @access protected
	 *
	 * @param array $assistant  Assistant settings
	 *
	 * @return array  List of the tools in the Responses API format
	 */
	protected function build_tools( $assistant ) {
		$tools = array();
		if ( ! empty( $assistant['vector_store_ids'] ) && is_array( $assistant['vector_store_ids'] ) ) {
			$file_search = array(
				'type'             => 'file_search',
				'vector_store_ids' => array_values( $assistant['vector_store_ids'] ),
			);
			$max_results = (int)apply_filters( 'trx_addons_filter_ai_helper_openai_assistants_file_search_max_results', 0, $assistant );
			if ( $max_results > 0 ) {
				$file_search['max_num_results'] = $max_results;
			}
			$tools[] = $file_search;
		}
		$functions = apply_filters( 'trx_addons_filter_ai_helper_openai_assistants_tools', array(), $assistant['id'], $assistant );
		return array_merge( $tools, $this->sanitize_tools( $functions ) );
	}

	/**
	 * Validate the function tools (Responses API format: flat objects with type=function)
	 *
	 * @access protected
	 *
	 * @param array $tools  Tools from the filter
	 *
	 * @return array  Valid tools only
	 */
	protected function sanitize_tools( $tools ) {
		$rez = array();
		$names = array();
		if ( ! is_array( $tools ) ) {
			return $rez;
		}
		foreach ( $tools as $tool ) {
			if ( ! is_array( $tool )
				|| empty( $tool['type'] ) || $tool['type'] !== 'function'
				|| empty( $tool['name'] ) || ! is_string( $tool['name'] ) || ! preg_match( '/^[A-Za-z0-9_-]{1,64}$/', $tool['name'] )
				|| in_array( $tool['name'], $names )
			) {
				continue;
			}
			$item = array(
				'type' => 'function',
				'name' => $tool['name'],
			);
			if ( ! empty( $tool['description'] ) && is_string( $tool['description'] ) ) {
				$item['description'] = $tool['description'];
			}
			// Parameters must be a JSON Schema object
			if ( ! empty( $tool['parameters'] ) && is_array( $tool['parameters'] ) && ! empty( $tool['parameters']['type'] ) && $tool['parameters']['type'] === 'object' ) {
				$item['parameters'] = $tool['parameters'];
				// An empty 'properties' array must be encoded as an object
				if ( isset( $item['parameters']['properties'] ) && is_array( $item['parameters']['properties'] ) && count( $item['parameters']['properties'] ) == 0 ) {
					$item['parameters']['properties'] = new \stdClass();
				}
			} else {
				$item['parameters'] = array(
					'type'                 => 'object',
					'properties'           => new \stdClass(),
					'additionalProperties' => false,
				);
			}
			if ( isset( $tool['strict'] ) ) {
				$item['strict'] = (bool)$tool['strict'];
			}
			$rez[] = $item;
			$names[] = $tool['name'];
		}
		return $rez;
	}

	/**
	 * Build the input items for the request: an optional 'developer' message with the system prompt + the messages
	 *
	 * @access protected
	 *
	 * @param array  $messages       Prepared messages: array( 'role', 'content' )
	 * @param string $system_prompt  System prompt (optional)
	 *
	 * @return array  Input items
	 */
	protected function build_input( $messages, $system_prompt = '' ) {
		$input = array();
		if ( ! empty( $system_prompt ) && is_string( $system_prompt ) ) {
			$input[] = array(
				'role' => 'developer',
				'content' => $system_prompt,
			);
		}
		if ( ! empty( $messages ) && is_array( $messages ) ) {
			foreach ( $messages as $message ) {
				if ( ! empty( $message['role'] ) && ! empty( $message['content'] ) ) {
					$input[] = array(
						'role' => $message['role'],
						'content' => $message['content'],
					);
				}
			}
		}
		return $input;
	}

	/**
	 * Return the metadata to attach to the conversation and responses.
	 * The request parameters ('max_output_tokens', 'temperature', 'text_format') are stored in the metadata too
	 * to reuse them when the results of the function calls are submitted (see get_args_from_metadata())
	 *
	 * @access protected
	 *
	 * @param array $assistant  Assistant settings
	 * @param array $args       Query arguments: 'max_tokens', 'temperature', 'response_format'
	 *
	 * @return array  Metadata: key => value (string)
	 */
	protected function get_metadata( $assistant, $args = array() ) {
		$metadata = array(
			'source'       => 'trx_addons',
			'assistant_id' => ! empty( $assistant['id'] ) ? (string)$assistant['id'] : '',
			'site'         => (string)wp_parse_url( home_url(), PHP_URL_HOST ),
		);
		if ( ! empty( $args['max_tokens'] ) && (int)$args['max_tokens'] > 0 ) {
			$metadata['max_output_tokens'] = (string)(int)$args['max_tokens'];
		}
		if ( isset( $args['temperature'] ) && $args['temperature'] !== '' && $args['temperature'] !== null ) {
			$metadata['temperature'] = (string)(float)$args['temperature'];
		}
		if ( ! empty( $args['response_format']['type'] ) && $args['response_format']['type'] == 'json_object' ) {
			$metadata['text_format'] = 'json_object';
		}
		$metadata = apply_filters( 'trx_addons_filter_ai_helper_openai_assistants_metadata', $metadata, $assistant, $args );
		// OpenAI limits: 16 key-value pairs, keys up to 64 characters, values up to 512 characters
		$rez = array();
		foreach ( $metadata as $k => $v ) {
			if ( is_string( $k ) && $k !== '' && is_scalar( $v ) ) {
				$rez[ substr( $k, 0, 64 ) ] = substr( (string)$v, 0, 512 );
			}
			if ( count( $rez ) >= 16 ) {
				break;
			}
		}
		return $rez;
	}

	/**
	 * Restore the query arguments from the metadata of the response (see get_metadata())
	 *
	 * @access protected
	 *
	 * @param array $metadata  Metadata of the response
	 *
	 * @return array  Query arguments: 'max_tokens', 'temperature', 'response_format'
	 */
	protected function get_args_from_metadata( $metadata ) {
		$args = array();
		if ( ! empty( $metadata['max_output_tokens'] ) && (int)$metadata['max_output_tokens'] > 0 ) {
			$args['max_tokens'] = (int)$metadata['max_output_tokens'];
		}
		if ( isset( $metadata['temperature'] ) && $metadata['temperature'] !== '' && is_numeric( $metadata['temperature'] ) ) {
			$args['temperature'] = (float)$metadata['temperature'];
		}
		if ( ! empty( $metadata['text_format'] ) && $metadata['text_format'] == 'json_object' ) {
			$args['response_format'] = array( 'type' => 'json_object' );
		}
		return $args;
	}

	/**
	 * Return the list of the function calls requested by the model
	 *
	 * @access private
	 *
	 * @param array $result  Response object from the API
	 *
	 * @return array  List of the calls: array( 'call_id', 'name', 'arguments' )
	 */
	private function get_function_calls( $result ) {
		$calls = array();
		if ( ! empty( $result['output'] ) && is_array( $result['output'] ) ) {
			foreach ( $result['output'] as $item ) {
				if ( ! empty( $item['type'] ) && $item['type'] == 'function_call' && ! empty( $item['name'] ) && ! empty( $item['call_id'] ) ) {
					$calls[] = array(
						'call_id' => $item['call_id'],
						'name' => $item['name'],
						'arguments' => ! empty( $item['arguments'] ) ? $item['arguments'] : '',
					);
				}
			}
		}
		return $calls;
	}

	/**
	 * Check if the error from the API is caused by a wrong/expired conversation ID
	 *
	 * @access private
	 *
	 * @param array $result  Raw result from the API
	 *
	 * @return bool
	 */
	private function is_conversation_error( $result ) {
		if ( ! is_array( $result ) || empty( $result['error'] ) || ! is_array( $result['error'] ) ) {
			return false;
		}
		if ( ! empty( $result['error']['param'] ) && $result['error']['param'] == 'conversation' ) {
			return true;
		}
		$message = ! empty( $result['error']['message'] ) ? $result['error']['message'] : '';
		return ! empty( $message )
				&& stripos( $message, 'conversation' ) !== false
				&& preg_match( '/not found|invalid|does not exist|no longer/i', $message );
	}

	/**
	 * Return a human-readable error message from the API result
	 *
	 * @access private
	 *
	 * @param array|string|bool $result   Raw result from the API
	 * @param string            $default  Default message
	 *
	 * @return string
	 */
	private function get_error_message( $result, $default ) {
		if ( is_array( $result ) ) {
			if ( ! empty( $result['error']['message'] ) ) {
				return $result['error']['message'];
			} else if ( ! empty( $result['error'] ) && is_string( $result['error'] ) ) {
				return $result['error'];
			}
		} else if ( is_string( $result ) && trim( $result ) !== '' ) {
			return $default . ': ' . wp_strip_all_tags( trx_addons_strshort( $result, 200 ) );
		}
		return $default;
	}

	/**
	 * Return the error message for the assistant which is not found in the plugin options
	 *
	 * @access private
	 *
	 * @param string $model  Model name (assistant ID)
	 *
	 * @return string
	 */
	private function get_assistant_not_found_message( $model ) {
		return sprintf(
			__( "The assistant '%s' is not found in the plugin options. Please, add it to the list of assistants (ThemeREX Addons - AI Helper - Open AI Assistants).", 'trx_addons' ),
			self::get_assistant_id( $model )
		);
	}

	/**
	 * Return the response with an error for the chat
	 *
	 * @access private
	 *
	 * @param string $error      Error message
	 * @param string $thread_id  Conversation ID
	 * @param string $run_id     Response ID
	 *
	 * @return array  Response for the chat
	 */
	private function prepare_error_response( $error, $thread_id = '', $run_id = '' ) {
		return array(
			'finish_reason' => 'error',
			'thread_id' => $thread_id,
			'run_id' => $run_id,
			'error' => $error,
		);
	}

	/**
	 * Convert the result of the response creation to the 'queued' response for the chat
	 *
	 * @access private
	 *
	 * @param array  $result     Raw result from the API: 'id', 'status' or 'error'
	 * @param string $thread_id  Conversation ID (empty for the single queries)
	 * @param string $error      Default error message
	 *
	 * @return array  Response for the chat
	 */
	private function prepare_queued_response( $result, $thread_id, $error ) {
		if ( is_array( $result ) && ! empty( $result['id'] ) ) {
			$response = array(
				'finish_reason' => 'queued',
				'run_id' => $result['id'],
				'thread_id' => $thread_id,
				'fetch_time' => self::FETCH_TIME,
			);
		} else {
			$response = $this->prepare_error_response( $this->get_error_message( $result, $error ), $thread_id );
		}
		return $response;
	}

	/**
	 * Convert a response object to the format, compatible with OpenAI API response
	 *
	 * @access protected
	 *
	 * @param array $response  Response object from the API: 'id', 'status', 'output', 'usage'
	 * @param array $args      Query arguments: 'model', 'thread_id', 'run_id'
	 *
	 * @return array  Response in the OpenAI API format: 'finish_reason', 'model', 'thread_id', 'run_id', 'response_id', 'usage', 'choices'
	 */
	protected function prepare_response( $response, $args ) {
		$content = ! empty( $response['output'] ) ? Utils::parse_responses_output( $response['output'] ) : '';
		if ( ! empty( $content ) && ! empty( $response['status'] ) && $response['status'] == 'incomplete' ) {
			$content .= '<br><em>' . esc_html__( '(The answer was cut off due to its length)', 'trx_addons' ) . '</em>';
		}
		$prompt_tokens     = ! empty( $response['usage']['input_tokens'] )  ? (int)$response['usage']['input_tokens']  : 0;
		$completion_tokens = ! empty( $response['usage']['output_tokens'] ) ? (int)$response['usage']['output_tokens'] : ( ! empty( $content ) ? $this->count_tokens( $content ) : 0 );
		$total_tokens      = ! empty( $response['usage']['total_tokens'] )  ? (int)$response['usage']['total_tokens']  : $prompt_tokens + $completion_tokens;
		return array(
			'finish_reason' => 'stop',
			'model' => ! empty( $args['model'] )
						? $args['model']
						: ( ! empty( $response['model'] )
							? $response['model']
							: __( 'OpenAI Assistant', 'trx_addons' )
							),
			'run_id' => ! empty( $args['run_id'] ) ? $args['run_id'] : '',
			'thread_id' => ! empty( $args['thread_id'] ) ? $args['thread_id'] : '',
			'response_id' => ! empty( $response['id'] ) ? $response['id'] : '',
			'usage' => array(
						'prompt_tokens' => $prompt_tokens,
						'completion_tokens' => $completion_tokens,
						'total_tokens' => $total_tokens,
						),
			'choices' => array(
							array(
								'message' => array(
									'role' => 'assistant',
									'content' => $content
								)
							)
						)
		);
	}

	/**
	 * Prepare args for the API: clean the messages and convert the attachments to the Responses API input format
	 *
	 * @access protected
	 *
	 * @param array $args  Query arguments
	 *
	 * @return array  Prepared query arguments
	 */
	protected function prepare_args( $args = array() ) {
		$messages = array();
		if ( ! empty( $args['messages'] ) && is_array( $args['messages'] ) ) {
			foreach ( $args['messages'] as $message ) {
				if ( empty( $message['role'] ) || ! in_array( $message['role'], array( 'user', 'assistant' ) ) || empty( $message['content'] ) || ! is_string( $message['content'] ) ) {
					continue;
				}
				$content = $message['content'];
				// Remove all Gutenberg block comments
				$content = preg_replace( '/<!--[^>]*-->/', '', $content );
				// The assistant messages in the chat history are stored as HTML - convert them back to the plain text
				if ( $message['role'] == 'assistant' ) {
					$content = preg_replace( '/<br\s*\/?>|<\/(p|li|h[1-6]|div|tr)>/i', "\n", $content );
					$content = html_entity_decode( wp_strip_all_tags( $content ), ENT_QUOTES | ENT_HTML5, 'UTF-8' );
				}
				// Remove duplicate newlines
				$content = trim( preg_replace( '/[\r\n]{2,}/', "\n", $content ) );
				if ( $content === '' ) {
					continue;
				}
				$item = array(
					'role' => $message['role'],
					'content' => $content,
				);
				// Add attachments (images) to the message content
				if ( $message['role'] == 'user' && ! empty( $message['attachments'] ) && is_array( $message['attachments'] ) ) {
					$item = $this->add_attachments_to_message_content( $item, $message['attachments'] );
				}
				$messages[] = $item;
			}
		}
		$args['messages'] = $messages;
		if ( ! empty( $args['model'] ) ) {
			$args['model'] = self::get_assistant_id( $args['model'] );
		}
		return $args;
	}

	/**
	 * Set a message content for the API as an array of the input parts if the attachments (images) are present.
	 * Audio attachments are not supported by the Responses API for these models and are skipped.
	 *
	 * @access private
	 *
	 * @param array $message      The message: 'role', 'content' (string)
	 * @param array $attachments  The attachments: array( array( 'name' => 'file name', 'file' => 'path to the uploaded file' ) )
	 *
	 * @return array  Prepared message
	 */
	private function add_attachments_to_message_content( $message, $attachments ) {
		$parts = array();
		$image_ext = Utils::get_allowed_attachments( 'image' );
		foreach ( $attachments as $attachment ) {
			if ( empty( $attachment['name'] ) || empty( $attachment['file'] ) || ! file_exists( $attachment['file'] ) ) {
				continue;
			}
			$ext = strtolower( pathinfo( $attachment['name'], PATHINFO_EXTENSION ) );
			if ( in_array( $ext, $image_ext ) ) {
				$parts[] = array(
					'type' => 'input_image',
					'image_url' => 'data:image/' . ( $ext == 'jpg' ? 'jpeg' : $ext ) . ';base64,' . base64_encode( trx_addons_fgc( $attachment['file'] ) ),
				);
			}
		}
		if ( count( $parts ) > 0 ) {
			$message['content'] = array_merge(
				array(
					array(
						'type' => 'input_text',
						'text' => $message['content'],
					)
				),
				$parts
			);
		}
		return $message;
	}

}
