<?php

namespace FluentBookingPro\App\Services\Integrations\Calendars\NextCloud;

use FluentBooking\App\Models\Meta;
use FluentBooking\App\Services\Helper;
use FluentBooking\Framework\Support\Arr;
use FluentBooking\App\Services\Integrations\Calendars\RemoteCalendarHelper;

class NextCloudHelper
{
    public static function getApiConfig()
    {
        $defaults = [
            'is_enabled'   => 'no',
            'base_url'     => '',
            'caching_time' => 5
        ];

        $settings = get_option('_fcal_next_cloud_calendar_client_details', []);

        $settings = wp_parse_args($settings, $defaults);

        return $settings;
    }

    /**
     * The base URL is set by `manage_all_data`, which is not necessarily an administrator,
     * so it must not be pointable at an internal service. See
     * RemoteCalendarHelper::shouldRejectUnsafeUrl() for the opt-out filter.
     *
     * @param string $baseUrl
     * @return string|\WP_Error
     */
    public static function sanitizeBaseUrl($baseUrl)
    {
        $baseUrl = trim((string)$baseUrl);

        if (!$baseUrl) {
            return '';
        }

        $baseUrl = RemoteCalendarHelper::sanitizeRemoteUrl($baseUrl, 'next_cloud_calendar');

        if (!$baseUrl) {
            return new \WP_Error(
                'invalid_base_url',
                __('Please provide a valid public http/https Nextcloud CalDav URL.', 'fluent-booking-pro')
            );
        }

        return $baseUrl;
    }

    public static function updateConfig($settings)
    {
        $baseUrl = self::sanitizeBaseUrl(Arr::get($settings, 'base_url', ''));

        if (is_wp_error($baseUrl)) {
            throw new \Exception($baseUrl->get_error_message());
        }

        $settings = [
            'is_enabled'   => Arr::get($settings, 'is_enabled', 'no'),
            'base_url'     => $baseUrl,
            'caching_time' => Arr::get($settings, 'caching_time', 5)
        ];

        update_option('_fcal_next_cloud_calendar_client_details', $settings, 'no');

        return $settings;
    }

    public static function getClientByMeta(Meta $meta)
    {
        $config = self::getApiConfig();

        if (empty($config['base_url']) || $config['is_enabled'] != 'yes') {
            return false;
        }

        $settings = $meta->value;
        $userName = Arr::get($settings, 'remote_email');
        $passWord = Helper::decryptKey(Arr::get($settings, 'remote_pass'));

        if (!$userName || !$passWord) {
            return new \WP_Error('invalid_credentials', __('Invalid credentials', 'fluent-booking-pro'));
        }

        return new NextcloudClient($config['base_url'], $userName, $passWord);
    }
}
