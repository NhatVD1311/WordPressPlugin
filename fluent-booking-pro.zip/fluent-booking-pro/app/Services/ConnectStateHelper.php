<?php

namespace FluentBookingPro\App\Services;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Binds a provider connect round-trip to the browser session that started it,
 * for the Google, Outlook and Stripe connect flows.
 *
 * The value is "<userId>-<randomToken>". The separator must stay "-": it is
 * left untouched by rawurlencode(), so the value survives however many
 * encode/decode passes a provider or broker applies to the redirect URI.
 */
class ConnectStateHelper
{
    const TTL = 900; // 15 minutes

    private static function transientKey($provider, $userId)
    {
        return 'fcal_connect_state_' . $provider . '_' . (int) $userId;
    }

    /**
     * @return string "<userId>-<token>"
     */
    public static function create($provider, $userId)
    {
        $token = wp_generate_password(32, false, false);
        set_transient(self::transientKey($provider, $userId), $token, self::TTL);

        return $userId . '-' . $token;
    }

    /**
     * @return int|false the validated user id, or false when invalid
     */
    public static function verify($provider, $rawState)
    {
        if (!is_string($rawState) || strpos($rawState, '-') === false) {
            return false;
        }

        list($userId, $token) = explode('-', $rawState, 2);

        $userId = (int) $userId;
        if (!$userId || $token === '') {
            return false;
        }

        $key    = self::transientKey($provider, $userId);
        $stored = get_transient($key);

        if (!$stored || !hash_equals((string) $stored, (string) $token)) {
            return false;
        }

        delete_transient($key); // single-use

        return $userId;
    }
}
