<?php

namespace FluentBookingPro\App\Http\Controllers;

use FluentBooking\App\Http\Controllers\Controller;
use FluentBooking\App\Models\CalendarSlot;
use FluentBooking\App\Models\Meta;
use FluentBooking\App\Services\Helper;
use FluentBooking\App\Services\PermissionManager;
use FluentBooking\App\Services\Integrations\Calendars\RemoteCalendarHelper;
use FluentBooking\Framework\Http\Request\Request;
use FluentBooking\Framework\Support\Arr;

class WebhookController extends Controller
{
    public function getFeeds(Request $request, $calendarId, $eventId)
    {
        $calendarEvent = CalendarSlot::where('calendar_id', $calendarId)->findOrFail($eventId);
        $feeds = Meta::where('object_id', $calendarEvent->id)
            ->where('object_type', 'calendar_event')
            ->where('key', 'webhook_feeds')
            ->get();

        $formattedFeeds = [];

        foreach ($feeds as $feed) {
            $formattedFeeds[] = [
                'id'       => $feed->id,
                'settings' => $feed->value,
            ];
        }

        return [
            'feeds'          => $formattedFeeds,
            'event_triggers' => $this->eventTriggers(),
            'smart_codes'    => [
                'texts' => Helper::getEditorShortCodes($calendarEvent),
                'html'  => Helper::getEditorShortCodes($calendarEvent, true)
            ]
        ];
    }

    public function saveFeed(Request $request, $calendarId, $eventId)
    {
        $calendarEvent = CalendarSlot::where('calendar_id', $calendarId)->findOrFail($eventId);
        $webhookFeed = $request->get('webhook', []);
        $settings = Arr::get($webhookFeed, 'settings', []);

        $this->validate($settings, [
            'name'           => 'required',
            'request_url'    => 'required',
            'request_body'   => 'required',
            'request_method' => 'required',
            'event_triggers' => 'required',
        ]);

        // Webhook URLs are set by anyone who can edit the event, so keep them to plain
        // http/https and off internal services.
        $requestUrl = RemoteCalendarHelper::sanitizeRemoteUrl(Arr::get($settings, 'request_url', ''), 'webhook');

        if (!$requestUrl) {
            return $this->sendError([
                'message' => __('Please provide a valid public http/https webhook URL.', 'fluent-booking-pro')
            ], 422);
        }

        $settings['request_url'] = $requestUrl;

        $settings['enabled'] = Arr::isTrue($settings, 'enabled');

        if (Arr::get($webhookFeed, 'id')) {
            $webhook = Meta::where('object_type', 'calendar_event')
                ->where('key', 'webhook_feeds')
                ->where('object_id', $calendarEvent->id)
                ->where('id', $webhookFeed['id'])
                ->first();

            if (!$webhook) {
                return $this->sendError([
                    'message' => __('WebHook not found', 'fluent-booking-pro')
                ], 422);
            }

            $webhook->value = $settings;
            $webhook->save();
            return [
                'message' => __('WebHook Successfully Updated', 'fluent-booking-pro'),
                'id'      => $webhook->id
            ];
        }

        // create new
        $data = [
            'value'       => $settings,
            'object_type' => 'calendar_event',
            'object_id'   => $calendarEvent->id,
            'key'         => 'webhook_feeds'
        ];

        $createdHook = Meta::create($data);

        return [
            'message' => __('WebHook Successfully Created', 'fluent-booking-pro'),
            'id'      => $createdHook->id
        ];
    }

    public function deleteFeed(Request $request, $calendarId, $eventId, $webhookId)
    {
        $event = CalendarSlot::where('calendar_id', $calendarId)->findOrFail($eventId);

        Meta::where('id', $webhookId)
            ->where('key', 'webhook_feeds')
            ->where('object_id', $event->id)
            ->delete();

        return [
            'message' => __('Selected Webhook has been deleted', 'fluent-booking-pro')
        ];
    }

    public function cloneFeeds(Request $request, $calendarId, $eventId)
    {
        $calendarEvent = CalendarSlot::where('calendar_id', $calendarId)->findOrFail($eventId);

        $fromEventId = intval($request->get('from_event_id'));

        $fromEvent = CalendarSlot::findOrFail($fromEventId);

        if (!PermissionManager::canUpdateCalendarEvent($fromEvent->id)) {
            return $this->sendError([
                'message' => __('You do not have access to the source event', 'fluent-booking-pro')
            ], 403);
        }

        $fromEventFeeds = Meta::where('object_id', $fromEvent->id)
            ->where('object_type', 'calendar_event')
            ->where('key', 'webhook_feeds')
            ->get();
        
        if ($fromEventFeeds->isEmpty()) {
            return $this->sendError([
                'message' => __('WebHook feeds not found', 'fluent-booking-pro')
            ], 422);
        }

        $cloned = 0;
        $skipped = 0;

        foreach ($fromEventFeeds as $feed) {
            $settings = $feed->value;

            // Feeds stored before saveFeed() validated destinations can hold URLs that would
            // now be rejected, so don't carry those onto another event.
            $requestUrl = RemoteCalendarHelper::sanitizeRemoteUrl(Arr::get($settings, 'request_url', ''), 'webhook');

            if (!$requestUrl) {
                $skipped++;
                continue;
            }

            $settings['request_url'] = $requestUrl;

            $cloneFeed = $feed->replicate();
            $cloneFeed->object_id = $calendarEvent->id;
            $cloneFeed->value = $settings;
            $cloneFeed->save();
            $cloned++;
        }

        if (!$cloned) {
            return $this->sendError([
                'message' => __('No WebHook could be cloned because their URLs are no longer valid', 'fluent-booking-pro')
            ], 422);
        }

        if ($skipped) {
            return [
                /* translators: %1$d: number of cloned webhooks, %2$d: number skipped for an invalid URL. */
                'message' => sprintf(__('%1$d WebHook(s) cloned, %2$d skipped for an invalid URL', 'fluent-booking-pro'), $cloned, $skipped)
            ];
        }

        return [
            'message' => __('WebHook Successfully Cloned', 'fluent-booking-pro')
        ];
    }

    protected function eventTriggers()
    {
        return [
            [
                'label' => __('Booking Confirmed', 'fluent-booking-pro'),
                'value' => 'after_booking_scheduled'
            ],
            [
                'label' => __('Booking Canceled', 'fluent-booking-pro'),
                'value' => 'booking_schedule_cancelled'
            ],
            [
                'label' => __('Booking Completed', 'fluent-booking-pro'),
                'value' => 'booking_schedule_completed'
            ],
            [
                'label' => __('Booking Rescheduled', 'fluent-booking-pro'),
                'value' => 'after_booking_rescheduled'
            ],
            [
                'label' => __('Booking Rejected', 'fluent-booking-pro'),
                'value' => 'booking_schedule_rejected'
            ]
        ];
    }
}
