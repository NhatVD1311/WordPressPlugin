<?php

namespace FluentBookingPro\App\Http\Policies;

use FluentBooking\Framework\Http\Request\Request;
use FluentBooking\Framework\Foundation\Policy;

class SuperAdminPolicy extends Policy
{
    /**
     * Gate for site-level operations (the pro license). Requires the WordPress
     * manage_options capability, never the delegable manage_all_data
     * permission that SettingsPolicy accepts.
     *
     * @param \FluentBooking\Framework\Http\Request\Request $request
     * @return Boolean
     */
    public function verifyRequest(Request $request)
    {
        return current_user_can('manage_options');
    }
}
