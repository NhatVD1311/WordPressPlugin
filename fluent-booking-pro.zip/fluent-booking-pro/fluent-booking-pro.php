<?php defined('ABSPATH') or die;
/**
 * Plugin Name: FluentBooking Pro
 * Description: The Pro version of FluentBooking Plugin
 * Version: 2.3.0
 * Author: WPManageNinja LLC
 * Author URI: https://fluentbooking.com
 * Plugin URI: https://fluentbooking.com
 * License: GPLv2 or later
 * Text Domain: fluent-booking-pro
 * Domain Path: /language
 */

if (defined('FLUENT_BOOKING_PRO_DIR_FILE')) {
    return;
}

define('FLUENT_BOOKING_PRO_DIR_FILE', __FILE__);
define('FLUENT_BOOKING_PRO_DIR', plugin_dir_path(__FILE__));
define('FLUENT_BOOKING_PRO_VERSION', '2.3.0');
define('FLUENT_BOOKING_PRO_DB_VERSION', '1.0.0');
define('FLUENT_BOOKING_MIN_CORE_VERSION', '2.3.0');

add_filter('pre_http_request', function($pre, $args, $url) {
    if (strpos($url, 'fluentapi.wpmanageninja.com') !== false && strpos($url, 'fluent-cart') !== false) {
return ['response' => ['code' => 200], 'body' => json_encode(['status' => 'valid', 'license_key' => 'gpldo000-0000-0000-0000-51A9E6E1A930', 'expiration_date' => '2099-12-31', 'activation_hash' => md5('gpldo00000000005603B1EBE59708542'), 'variation_id' => '1', 'variation_title' => 'Agency License'])];
    }
    return $pre;
}, 10, 3);
update_option('__fluent_booking_pro_license', ['license_key' => 'gpldo000-0000-0000-0000-51A9E6E1A930', 'status' => 'valid', 'variation_id' => '1', 'variation_title' => 'Agency License', 'expires' => '2099-12-31', 'activation_hash' => md5('gpldo00000000005603B1EBE59708542')], false);

require __DIR__ . '/vendor/autoload.php';

call_user_func(function ($bootstrap) {
    $bootstrap(__FILE__);
}, require(__DIR__ . '/boot/app.php'));
